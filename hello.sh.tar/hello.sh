#!/bin/bash
echo "hello world"
echo "knowledge is power"
